extern crate cpal;

use crate::modules::models::audio_folder_model::AudioFolderModel;
use crate::modules::services::audio_loader::AudioLoader;
use cpal::Stream;
use std::path::PathBuf;
use std::sync::{Arc, Mutex};
use std::time::Instant;

pub struct PlayerController<L: AudioLoader> {
    audio_model: Arc<Mutex<AudioFolderModel>>,
    audio_loader: L,        // Injected audio loader
    stream: Option<Stream>, // Store the current stream
    is_paused: bool,        // Track if the player is paused
}

impl<L: AudioLoader> PlayerController<L> {
    pub fn new(audio_model: Arc<Mutex<AudioFolderModel>>, audio_loader: L) -> Self {
        PlayerController {
            audio_model,
            audio_loader,
            stream: None,
            is_paused: true,
        }
    }

    pub fn load_current(&mut self) {
        let current_file = self.get_current_file();
        println!("[SENSIT_LOG] Loading file: {:?}", current_file.display());

        let start_time = Instant::now();

        // Step 1: Use the audio loader to create a stream for the current file
        match self.audio_loader.create_audio_stream(&current_file) {
            Ok(stream) => {
                self.stream = Some(stream);
                println!(
                    "[SENSIT_LOG] Stream created successfully for file {:?} in {:?}.",
                    current_file.display(),
                    start_time.elapsed()
                );

                self.toggle_play(); // Start playing the stream
            }
            Err(err) => {
                eprintln!("[ERROR] Failed to create stream: {:?}", err);
            }
        }
    }

    fn get_current_file(&self) -> PathBuf {
        let audio_model = self.audio_model.lock().unwrap();
        audio_model.get_current_file().to_path_buf()
    }

    pub fn toggle_play(&mut self) {
        if let Some(stream) = &self.stream {
            if !self.is_paused {
                stream.pause().unwrap();
                self.is_paused = true;
                println!("[SENSIT_LOG] Playback paused.");
            } else {
                stream.play().unwrap();
                self.is_paused = false;
                println!("[SENSIT_LOG] Playback resumed.");
            }
        } else {
            println!("[ERROR] No active stream to toggle play/pause.");
        }
    }

    pub fn next(&mut self) {
        self.audio_model.lock().unwrap().next_track();
        println!("[SENSIT_LOG] Playing next track...");
        self.load_current();
    }

    pub fn prev(&mut self) {
        self.audio_model.lock().unwrap().prev_track();
        println!("[SENSIT_LOG] Playing previous track...");
        self.load_current();
    }
}
